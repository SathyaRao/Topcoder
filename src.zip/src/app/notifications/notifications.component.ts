import { Component, OnInit } from '@angular/core';
declare var $: any;
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  id = 0;
  paramsSubscription: Subscription;
  items:Array<any>=[];
  isComment:boolean;
  comment:string;
  question:string;
stars: number[] = [1, 2, 3, 4, 5];
    selectedValue: number;
    allQues: Array<any>=[];
  constructor(private route: ActivatedRoute, private http: HttpClient) { }

  countStar(star) {
      this.selectedValue = star;
      console.log('Value of star', star);
    }
    
  showNotification(from, align){
      const type = ['','info','success','warning','danger'];

      const color = Math.floor((Math.random() * 4) + 1);

      $.notify({
          icon: "notifications",
          message: "Welcome to <b>Material Dashboard</b> - a beautiful freebie for every web developer."

      },{
          type: type[color],
          timer: 4000,
          placement: {
              from: from,
              align: align
          },
          template: '<div data-notify="container" style="height:60%" class="col-xl-6 col-lg-6 col-11 col-sm-6 col-md-6 alert alert-{0} alert-with-icon" role="alert">' +
            '<button mat-button  type="button" aria-hidden="true" class="close mat-button" data-notify="dismiss">  <i class="material-icons">close</i></button>' +
            '<i class="material-icons" data-notify="icon">notifications</i> ' +
            '<span data-notify="title">{1}</span> ' +
            '<span data-notify="message">{2}</span>' +
            '<div class="progress" data-notify="progressbar">' +
              '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
            '</div>' +
            '<a href="{3}" target="{4}" data-notify="url"></a>' +
          '</div>'
      });
  }
  ngOnInit() {
    this.paramsSubscription = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
    });
    var id = this.getCookie("quesid");
    //this.items = ["What is the relationship between hashCode() and equals()? What is the significance of these methods? What are the requirements for implementing them?"];
    this.getQuestion(id);
  }

  getCookie(name){
    var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    if (match) return match[2];
  }
  addComment(){
    this.isComment = true;
  }
  addRating(){

  }

  submitComment(){
    this.isComment = false;
    this.items.push(this.comment);
    /*this.http.get('../../assets/json/questions.json').subscribe(data => {     
        var ques=[];
        ques.push(data);
        for(var i=0;i<ques[0].length;i++){
          this.allQues.push(data[i]);
          if(data[i].id == id){
            this.question = data[i].questionTitle;
          }
        }        
    });*/
    this.comment = "";
  }

  closeComment(){
    this.isComment = false;
    this.comment = "";
  }

  getQuestion(id){
    this.http.get('../../assets/json/questions.json').subscribe(data => {     
        var ques=[];
        ques.push(data);
        for(var i=0;i<ques[0].length;i++){
          this.allQues.push(data[i]);
          if(data[i].id == id){
            this.question = data[i].questionTitle;
          }
        }        
    });
  }

}
