import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}
export const ROUTES: RouteInfo[] = [
    { path: '/dashboard', title: 'Dashboard',  icon: 'dashboard', class: '' },
    { path: '/user-profile', title: 'User Profile',  icon:'person', class: '' },
   /* { path: '/table-list', title: 'Table List',  icon:'content_paste', class: '' },
    { path: '/typography', title: 'Typography',  icon:'library_books', class: '' },
    { path: '/icons', title: 'Icons',  icon:'bubble_chart', class: '' },
    { path: '/maps', title: 'Maps',  icon:'location_on', class: '' },*/
    { path: '/notifications', title: 'Table List',  icon:'library_books', class: '' },
  //  { path: '/upgrade', title: 'Upgrade to PRO',  icon:'unarchive', class: 'active-pro' },
];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  menuItems: any[];
  userId: string;
  users: Array<any> = [];
  loggedInUser:Array<any> = [];

  constructor(private route: ActivatedRoute, private http:HttpClient) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.userId = params['param1']; // (+) converts string 'id' to a number
      if(this.userId == undefined || this.userId == null || this.userId == ""){
        this.userId = this.getCookie("userId");
      }
    });
    this.http.get('../../assets/json/users.json').subscribe(data => {     
        var users=[];
        users.push(data);
        for(var i=0;i<users[0].length;i++){          
          if(data[i].id == this.userId){
            this.loggedInUser.push(data[i]);
          }
        }        
    });
    this.menuItems = ROUTES.filter(menuItem => menuItem);
    
  }
  getCookie(name){
    var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    if (match) return match[2];
  }
  isMobileMenu() {
      if ($(window).width() > 991) {
          return false;
      }
      return true;
  };
}
