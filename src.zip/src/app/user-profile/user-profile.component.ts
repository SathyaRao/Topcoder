import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  param:string;
  users: Array<any> = [];
  loggedInUser:Array<any> = [];
  constructor(private route: ActivatedRoute, private http: HttpClient) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
        this.param = params['param1'];
        if(this.param == undefined || this.param == null || this.param == ""){
          this.param = this.getCookie("userId");
        }
    });
    
    this.http.get('../../assets/json/users.json').subscribe(data => {     
        var users=[];
        users.push(data);
        for(var i=0;i<users[0].length;i++){          
          if(data[i].id == this.param){
            this.loggedInUser.push(data[i]);
          }
        }        
    });
  } 
 
  getCookie(name){
    var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    if (match) return match[2];
  }

}
